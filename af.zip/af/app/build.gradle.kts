plugins {
    id ("com.android.application")
    id ("com.google.gms.google-services")
}

android {
    namespace 'com.exemplo.listadecompras'
    compileSdk 34

    defaultConfig {
        applicationId "com.exemplo.listadecompras"
        minSdk 21
        targetSdk 34
        versionCode 1
        versionName "1.0"
    }

    buildTypes {
        release {
            minifyEnabled false
        }
    }
}

dependencies {
    implementation ("com.google.firebase:firebase-database:20.3.0")
    implementation ("com.google.firebase:firebase-analytics:21.5.0")
    implementation ("androidx.appcompat:appcompat:1.6.1")
    implementation ("com.google.android.material:material:1.11.0")
    implementation ("androidx.constraintlayout:constraintlayout:2.1.4")




}
