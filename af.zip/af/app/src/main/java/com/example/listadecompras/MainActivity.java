package com.example.listadecompras;

import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {
    private EditText edtItem, edtQuantidade;
    private Button btnAdicionar;
    private ListView listView;

    private List<Item> itens;
    private ItemAdapter adapter;

    private DatabaseReference databaseRef;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        edtItem = findViewById(R.id.edtItem);
        edtQuantidade = findViewById(R.id.edtQuantidade);
        btnAdicionar = findViewById(R.id.btnAdicionar);
        listView = findViewById(R.id.listView);

        itens = new ArrayList<>();
        adapter = new ItemAdapter(this, itens);
        listView.setAdapter(adapter);

        databaseRef = FirebaseDatabase.getInstance().getReference("itens");

        btnAdicionar.setOnClickListener(v -> adicionarItem());

        recuperarItens();
    }

    private void adicionarItem() {
        String nome = edtItem.getText().toString().trim();
        String qtdStr = edtQuantidade.getText().toString().trim();

        if (nome.isEmpty() || qtdStr.isEmpty()) {
            Toast.makeText(this, "Preencha todos os campos", Toast.LENGTH_SHORT).show();
            return;
        }

        int quantidade = Integer.parseInt(qtdStr);
        String id = databaseRef.push().getKey();

        Item item = new Item(id, nome, quantidade);
        databaseRef.child(id).setValue(item);

        edtItem.setText("");
        edtQuantidade.setText("");
    }

    private void recuperarItens() {
        databaseRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                itens.clear();
                for (DataSnapshot ds : snapshot.getChildren()) {
                    Item item = ds.getValue(Item.class);
                    itens.add(item);
                }
                adapter.notifyDataSetChanged();
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                Toast.makeText(MainActivity.this, "Erro ao carregar dados", Toast.LENGTH_SHORT).show();
            }
        });
    }
}
