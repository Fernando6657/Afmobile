package com.example.listadecompras;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.Switch;
import android.widget.TextView;

import androidx.annotation.NonNull;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.util.List;

public class ItemAdapter extends ArrayAdapter<Item> {
    private Context context;
    private List<Item> itens;

    public ItemAdapter(Context context, List<Item> itens) {
        super(context, 0, itens);
        this.context = context;
        this.itens = itens;
    }

    @NonNull
    @Override
    public View getView(int position, View convertView, @NonNull ViewGroup parent) {
        Item item = itens.get(position);

        if (convertView == null) {
            convertView = LayoutInflater.from(context).inflate(R.layout.item_lista, parent, false);
        }

        TextView txtNome = convertView.findViewById(R.id.txtNome);
        TextView txtQuantidade = convertView.findViewById(R.id.txtQuantidade);
        CheckBox checkComprado = convertView.findViewById(R.id.checkComprado);
        LinearLayout layoutPreco = convertView.findViewById(R.id.layoutPreco);
        EditText edtPreco = convertView.findViewById(R.id.edtPreco);
        Switch switchTipo = convertView.findViewById(R.id.switchTipo);

        txtNome.setText(item.getNome());
        txtQuantidade.setText("Qtd: " + item.getQuantidade());
        checkComprado.setChecked(item.isComprado());

        if (item.isComprado()) {
            layoutPreco.setVisibility(View.VISIBLE);
            edtPreco.setText(String.valueOf(item.getPreco()));
            switchTipo.setChecked(item.isPorQuilo());
        } else {
            layoutPreco.setVisibility(View.GONE);
        }

        checkComprado.setOnCheckedChangeListener((buttonView, isChecked) -> {
            item.setComprado(isChecked);
            if (isChecked) {
                layoutPreco.setVisibility(View.VISIBLE);
            } else {
                layoutPreco.setVisibility(View.GONE);
                item.setPreco(0.0);
                item.setPorQuilo(false);
            }
            atualizarFirebase(item);
        });

        edtPreco.setOnFocusChangeListener((v, hasFocus) -> {
            if (!hasFocus) {
                String precoStr = edtPreco.getText().toString();
                double preco = precoStr.isEmpty() ? 0.0 : Double.parseDouble(precoStr);
                item.setPreco(preco);
                atualizarFirebase(item);
            }
        });

        switchTipo.setOnCheckedChangeListener((buttonView, isChecked) -> {
            item.setPorQuilo(isChecked);
            atualizarFirebase(item);
        });

        return convertView;
    }

    private void atualizarFirebase(Item item) {
        DatabaseReference ref = FirebaseDatabase.getInstance().getReference("itens");
        ref.child(item.getId()).setValue(item);
    }
}
